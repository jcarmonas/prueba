import sqlite3
import pandas as pd

conn = sqlite3.connect('gastos_clientes')
cur = conn.cursor()

cur.execute('DROP TABLE IF EXISTS cliente_compras_tdc_td')
conn.commit()
cur.execute('''CREATE TABLE cliente_compras_tdc_td (
    id_registro integer not null primary key,
    documento text,
    tipo_doc tinyint,
    categoria text,
    mnt_trx_mm double,
    num_trx int,
    pct_mnt_tot double,
    pct_num_trx_tot double
    )
    ''')
conn.commit()

df = pd.read_csv(r'./insumos/datos_base_clientes.csv')
df.to_sql('cliente_compras_tdc_td', conn, if_exists='append', index=False)

cur.execute('''
            SELECT * FROM cliente_compras_tdc_td
            LIMIT 10
            ''')

for row in cur.fetchall():
    print(row)

df = pd.read_sql('''
            SELECT * FROM cliente_compras_tdc_td
            ''', conn)
df.to_csv('cliente_compras_tdc_td.csv', index = False)

conn.close()
