import boto3
import json

with open(r'./static/config.json', encoding='utf-8') as config_file:
    config = json.load(config_file)

filename = 'cliente_compras_tdc_td.csv'
bucket_name = 'lc-pers-bucket'

s3 = boto3.client('s3',
                  aws_access_key_id=config['globals']['aws']['ACCESS_KEY'],
                  aws_secret_access_key=config['globals']['aws']['SECRET_KEY'],
                  region_name=config['globals']['aws']['DEFAULT_REGION']
                  )

response = s3.list_buckets()
buckets = [bucket['Name'] for bucket in response['Buckets']]
print(buckets)

if bucket_name not in buckets:
    s3.create_bucket(Bucket = bucket_name)

print('Bucket List: %s' % buckets)

s3.upload_file(Filename=filename, Bucket=bucket_name, Key = filename)