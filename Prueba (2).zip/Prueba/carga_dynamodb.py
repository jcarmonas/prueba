import json
import boto3
import os
import sqlite3
from decimal import Decimal
import pandas as pd

with open(r'./static/config.json', encoding='utf-8') as config_file:
    config = json.load(config_file)

s3 = boto3.client('s3',
                  aws_access_key_id=config['globals']['aws']['ACCESS_KEY'],
                  aws_secret_access_key=config['globals']['aws']['SECRET_KEY'],
                  region_name=config['globals']['aws']['DEFAULT_REGION']
                  )
dynamodb = boto3.client('dynamodb',
                  aws_access_key_id=config['globals']['aws']['ACCESS_KEY'],
                  aws_secret_access_key=config['globals']['aws']['SECRET_KEY'],
                  region_name=config['globals']['aws']['DEFAULT_REGION']
                  )

dynamodb_resource = boto3.resource('dynamodb',
                  aws_access_key_id=config['globals']['aws']['ACCESS_KEY'],
                  aws_secret_access_key=config['globals']['aws']['SECRET_KEY'],
                  region_name=config['globals']['aws']['DEFAULT_REGION']
                  )

filename = 'cliente_compras_tdc_td.csv'
bucket_name = 'lc-pers-bucket'
table_name = 'cliente_compras_tdc_td'

try:
    table = dynamodb.create_table(
        TableName = table_name,
        KeySchema = [
            {
                'AttributeName': 'id_registro',
                'KeyType': 'HASH' #Partition_key         
            } 
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'id_registro',
                'AttributeType': 'N'         
            }
        ],
        ProvisionedThroughput = {
            'ReadCapacityUnits': 1,
            'WriteCapacityUnits': 1
        }
        
        )
except dynamodb.exceptions.ResourceInUseException:

    obj = s3.get_object(Bucket= bucket_name, Key= filename)
    initial_df = pd.read_csv(obj['Body'])
    initial_df['documento'] = initial_df['documento'].astype(str)
    rows = list(initial_df.itertuples(index=False, name=None))
    field_names = list(initial_df.columns)
    table = dynamodb_resource.Table(table_name)
    filas, columnas = initial_df.shape
    for i in range(0, filas, 1000):
        df = initial_df[i:i+1000].copy()
        rows = list(initial_df.itertuples(index=False, name=None))
        items_to_append = []
        for row in rows:
            result = dict(zip(field_names, row))
            result = json.loads(json.dumps(result), parse_float=Decimal)
            items_to_append.append(result)
        with table.batch_writer() as batch:
            for item in items_to_append:
                response = batch.put_item(
                    Item={
                        "id_registro": item["id_registro"],
                        "documento": str(item["documento"]),
                        "tipo_doc": item["tipo_doc"],
                        "categoria": item["categoria"],
                        "mnt_trx_mm": item["mnt_trx_mm"],
                        "num_trx": item["num_trx"],
                        "pct_mnt_tot": item["pct_mnt_tot"],
                        "pct_num_trx_tot": item["pct_num_trx_tot"]
                    }
                    )
