import json
import boto3
import os
import sqlite3
from decimal import Decimal

s3 = boto3.resource('s3')
dynamodb = boto3.resource('dynamodb')


bucket_name = os.environ.get('bucket')
filename = os.environ.get('key')
table_name = os.environ.get('table')

def lambda_handler(event, context):
    try:
        testbucket = s3.Bucket(bucket_name)
        testbucket.download_file(filename, 'tmp/temp_database')
    except Exception as e:  
        print(e)
    try:
        _ = dynamodb.Table(table_name)
    except Exception as e:  
        print(e)
    
    conn = sqlite3.connect('tmp/temp_database')
    cur = conn.cursor()
    
    cur.execute('''
            SELECT * FROM cliente_compras_tdc_td
            ''')
    field_names = [field[0] for field in cur.description]
    for row in cur.fetchall():
        print(row)
        result = dict(zip(field_names[1:], row[1:]))
        try:
            dynamodb.put_item(
                TableName = table_name,
                Item = {
                    'id_registro': {'N': row[0]},
                    'trx': json.loads(json.dumps(result), parse_float=Decimal)                    
                }
            )
        except Exception as e:
            print(e)